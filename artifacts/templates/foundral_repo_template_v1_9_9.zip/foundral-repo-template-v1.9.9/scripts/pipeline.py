#!/usr/bin/env python3
"""
Foundral Template v1.9.9 — pipeline stub

Replace this with your project pipeline steps.
Minimum expectation:
- read config
- write something into data/derived/
- optionally generate site/report.html
"""
from __future__ import annotations
import argparse
from pathlib import Path
import json
from datetime import datetime, timezone

import yaml

def load_config(p: Path) -> dict:
    return yaml.safe_load(p.read_text(encoding="utf-8"))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    args = ap.parse_args()

    cfg = load_config(Path(args.config))
    data_dir = Path(cfg.get("data", {}).get("output_dir", "data"))
    site_dir = Path(cfg.get("data", {}).get("site_dir", "site"))
    (data_dir/"derived").mkdir(parents=True, exist_ok=True)
    site_dir.mkdir(parents=True, exist_ok=True)

    payload = {
        "ts_utc": datetime.now(timezone.utc).isoformat(),
        "project": cfg.get("project", {}),
        "message": "Template pipeline ran successfully. Replace scripts/pipeline.py with your real pipeline."
    }
    (data_dir/"derived"/"pipeline_ok.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    # Optional minimal report
    (site_dir/"report.html").write_text(
        "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>Foundral Template Report</title></head><body style='font-family:system-ui;padding:20px'>"
        "<h1>Foundral Template v1.9.9</h1><p>Pipeline ran OK.</p>"
        "<pre>" + json.dumps(payload, indent=2) + "</pre></body></html>",
        encoding="utf-8"
    )

    print("OK: pipeline complete")

if __name__ == "__main__":
    main()
