#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

CFG="config/config.yaml"
if [ ! -f "$CFG" ]; then
  CFG="config/config.example.yaml"
fi

python scripts/pipeline.py --config "$CFG"

echo "DONE."
echo "If your pipeline builds a report, open: site/report.html"
