# Foundral Repo Template v1.9.9

This repo is bootstrapped from **Foundral Repo Template v1.9.9**.

## Quick start (macOS)
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp config/config.example.yaml config/config.yaml
bash scripts/run_daily.sh
```

## What to edit first
- `project.name` in `config/config.yaml`
- `scripts/*.py` to match your project pipeline
- `docs/` to reflect your project canon + decisions

## Release workflow
```bash
git add .
git commit -m "init: bootstrap from Foundral template v1.9.9"
git tag -a v0.1.0 -m "init"
git push -u origin main
git push origin --tags
```
