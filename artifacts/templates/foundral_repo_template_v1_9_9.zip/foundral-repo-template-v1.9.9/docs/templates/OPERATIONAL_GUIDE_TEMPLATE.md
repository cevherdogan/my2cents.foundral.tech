# Operational Guide (Dev Runbook) — <PROJECT> <VERSION>

## Local run
```bash
bash scripts/run_daily.sh
```

## Validation checklist
-

## Commit vs ignore policy
-

## Tag + push
```bash
git tag -a <VERSION> -m "<PROJECT> <VERSION>"
git push origin --tags
```
