# Foundral Repo Template — v1.9.9

This template is a **vendor-neutral, automation-first repo skeleton** designed for Foundral-style projects.

## Included
- Standard directories: `docs/ config/ scripts/ data/ site/ ops/ .github/`
- Safe `.gitignore` for Python + data + secrets + reports
- Config pattern: `config.example.yaml` → `config.yaml` (gitignored)
- Scripts wiring: `run_daily.sh` + python entrypoints
- Docs templates: release notes, operational guide, changelog

## Intended usage
1) Unzip into a new folder
2) Rename placeholders in README / config
3) Initialize git + tag your project version
